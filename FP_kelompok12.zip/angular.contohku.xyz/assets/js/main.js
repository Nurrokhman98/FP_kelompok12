var base_url = 'http://localhost:84/';
var myApp = angular.module('myApp', ['ngRoute', 'ngResource', 'ngCart']);

// Route =======
myApp.config(['$routeProvider', function($routeProvider){
    $routeProvider.
    when('/', {
        templateUrl:'/template/views/home.html',
        controller:'homeController',
    })
    .when('/detail/:id', {
        templateUrl:'/template/views/detail.html',
        controller:'detailController',
    })
    .when('/cart', {
        templateUrl:'/template/views/cart.html',
        controller:'cartController',
    })
    .when('/checkout', {
        templateUrl:'/template/views/checkout.html',
        controller:'checkoutController',
    })
    .when('/checkout/:id', {
        templateUrl:'/template/views/summary.html',
        controller:'summaryController',
    })
    .when('/product', {
        templateUrl:'/template/views/product-list.html',
        controller:'productListController',
    })
    .when('/product/new', {
        templateUrl:'/template/views/new-product.html',
        controller:'newProductController',
    })
    .when('/product/view/:id', {
        templateUrl:'/template/views/detail-product.html',
        controller:'detailProductController',
    })
    .when('/product/delete/:id', {
        templateUrl:'/template/views/detail-product.html',
        controller:'deleteProductController',
    })
    .when('/user', {
        templateUrl:'/template/views/user-list.html',
        controller:'userListController',
    })
    .when('/user/:id', {
        templateUrl:'/template/views/detail-user.html',
        controller:'detailUserController',
    });
}]);

// Controller ======
myApp.controller("homeController", function($scope, $http){
  $http.get(base_url+"webservices/allProducts.php")
  .success(function(response){
    $scope.products = response.info;
  });
  gmaps();
});
myApp.controller("detailController", function($scope, $http, $routeParams){
  $http({
    url: base_url+"webservices/detailProduct.php",
    params:{id:$routeParams.id},
    method: "get"
  })
  .then(function(response){
    $scope.products = response.data;
  });
  $http.get(base_url+"webservices/allProducts.php")
  .success(function(response){
    $scope.product_list = response.info;
  });
});
myApp.controller("cartController", function($scope, $http, ngCart){
  ngCart.setTaxRate(7.5);
    ngCart.setShipping(2.99);
});
myApp.controller("checkoutController", function($scope){

  $("#newUser").validate({
    rules: {
        name: {
            required: true
        },
        email: {
            required: true,
            email: true
        },
        address: {
            required: true,
            minlength: 10
        }
    },
    messages: {
      name: {
          required: "Please input your name."
      },
      email: {
          required: "Please input your email.",
          email: "Please enter a valid email."
      },
      address: {
          required: "Please input your address.",
          minlength: "Please enter at least 3 characters"
      }
    },
    submitHandler: function(element) {

        var ajaxform = $(element),
            url =base_url+'webservices/newUser.php';
            console.log(ajaxform.serialize());


        $.ajax({
            url: url,
            data: ajaxform.serialize(),
            type: 'POST',
            cache: false,
            success: function(result) {
                $("#msg").html(result);
                window.location.href = base_url+'#/checkout/'+result.id;
            }
        });

        return false;
        }
  });

});
myApp.controller("summaryController", function($scope, $http, $routeParams){
  $http({
    url: base_url+"webservices/getUser.php",
    params:{id:$routeParams.id},
    method: "get"
  })
  .then(function(response){
    $scope.users = response.data;
  });
});

myApp.controller("productListController", function($scope, $http){
  $http.get(base_url+"webservices/allProducts.php")
  .success(function(response){
    $scope.products = response.info;
  });
  $scope.del = function(id){
			var confirms = confirm('Are you sure Delete this Project');
      if(confirms===true){
        $.ajax({
          type: 'post',
          url: base_url+'webservices/deleteProduct.php?id='+id,
          success: function(result){
            alert(result.msg)? "" : location.reload();
          }
        });
      }
		};
});
myApp.controller("detailProductController", function($scope, $http, $routeParams){
  $http({
    url: base_url+"webservices/detailProduct.php",
    params:{id:$routeParams.id},
    method: "get"
  })
  .then(function(response){
    $scope.products = response.data;
  });
});
myApp.controller("deleteProductController", function($scope, $http, $routeParams){
  $http({
    url: base_url+"webservices/deleteProduct.php",
    params:{id:$routeParams.id},
    method: "get"
  })
  .then(function(response){
    $scope.products = response.data;
  });
});
myApp.controller("newProductController", function($scope){
  $("#newProduct").validate({
    rules: {
        name: {
            required: true
        },
        description: {
            required: true,
            minlength: 10
        },
        price: {
            required: true,
            number: true
        },
        qty: {
            required: true,
            number: true

        }
    },
    messages: {
      name: {
          required: "Please input name product."
      },
      description: {
          required: "Please input name product.",
          minlength: "Please enter at least 3 characters"
      },
      price: {
          required: "Please input price product",
          number: "Please enter a valid number"
      },
      qty: {
          required: "Please input quantity",
          number: "Please enter a valid number"

      }
    },
    submitHandler: function(element) {

        var ajaxform = $(element),
            url =base_url+'webservices/newProduct.php';
            console.log(ajaxform.serialize());


        $.ajax({
            url: url,
            data: ajaxform.serialize(),
            type: 'POST',
            cache: false,
            success: function(result) {
                $("#msg").html(result);
                ajaxform.trigger("reset");
            }
        });

        return false;
        }
  });
});

myApp.controller("userListController", function($scope, $http){
  $http.get(base_url+"webservices/allUsers.php")
  .success(function(response){
    $scope.users = response.info;
  });
  $scope.del = function(id){
			var confirms = confirm('Are you sure Delete this User');
      if(confirms===true){
        $.ajax({
          type: 'post',
          url: base_url+'webservices/deleteUser.php?id='+id,
          success: function(result){
            alert(result.msg)? "" : location.reload();
          }
        });
      }
		};
});
myApp.controller("detailUserController", function($scope, $http, $routeParams){
  $http({
    url: base_url+"webservices/getUser.php",
    params:{id:$routeParams.id},
    method: "get"
  })
  .then(function(response){
    $scope.users = response.data;
  });
});
