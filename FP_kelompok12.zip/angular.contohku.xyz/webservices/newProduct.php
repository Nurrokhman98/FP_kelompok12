<?php
  include_once('config.php');
  $name = $_POST['name'];
  $description = $_POST['description'];
  $price = $_POST['price'];
  $qty = $_POST['qty'];

  $query = "INSERT INTO product(name, description, price, qty) values('$name','$description','$price','$qty')";
  if($con->query($query) == TRUE){
    echo '<div class="alert alert-dismissible alert-success">Product Added Succesfully</div>';
  }else{
    echo '<div class="alert alert-dismissible alert-warning">Failed to Add Post</div>';
  }
?>
