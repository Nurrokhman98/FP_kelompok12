<?php
  include_once('config.php');
  $id = $_GET['id'];
  if (!empty($id)) {
    $sql = "SELECT * FROM user WHERE id ='$id'";
    $query = $con->query($sql);
    if ($query->num_rows > 0) {
      while ($row = $query->fetch_array()) {
        $result = [
          'id' => $row['id'],
          'name' => $row['name'],
          'email' => $row['email'],
          'address' => $row['address']
        ];
      }
      $json = $result;
    }
    else{
      $json = ['status' => 0, 'msg'=>'Not Found'];
    }
    @mysqli_close();
    header('Content-type: application/json');
    echo json_encode($json);
  }
?>
