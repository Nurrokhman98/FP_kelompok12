<?php
  include_once('config.php');
  $id = $_GET['id'];
  if (!empty($id)) {
    $sql = "DELETE FROM user WHERE id = '$id'";
    $query = $con->query($sql);
    if ($query) {
        $result = ['status' => 1, 'msg'=>'User Deleted'];
    }else{
      $result = ['status' => 0, 'msg'=>'Failed to delete'];
    }
    @mysqli_close();
    header('Content-type: application/json');
    echo json_encode($result);
  }
?>
