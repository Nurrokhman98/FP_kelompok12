<?php
  include_once('config.php');
  $name = $_POST['name'];
  $email = $_POST['email'];
  $address = $_POST['address'];

  $query = "INSERT INTO user(name, email, address) values('$name','$email','$address')";
  if($con->query($query) == TRUE){
    $json = ['id' => $con->insert_id];
    @mysqli_close();
    header('Content-type: application/json');
    echo json_encode($json);
  }else{
    echo '<div class="alert alert-dismissible alert-warning">Failed to Add Post</div>';
  }
?>
