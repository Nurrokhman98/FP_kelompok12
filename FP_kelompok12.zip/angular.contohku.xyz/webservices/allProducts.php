<?php
  include_once('config.php');
  $sql = "SELECT * FROM product ORDER by id DESC";
  $query = $con->query($sql);
  if ($query->num_rows > 0) {
    while($row = $query->fetch_array()){
      $result[] = [
        'id' => $row['id'],
        'name' => $row['name'],
        'price' => $row['price'],
        'description' => $row['description'],
        'qty' => $row['qty']
      ];
    }
    $json = ['status' => 1, 'info' => $result];
  }else{
    $json = ['status' => 0, 'msg' => 'No Record Found'];
  }
  @mysqli_close();
  header('Content-type: application/json');
  echo json_encode($json);
?>
