<?php
  define('BASE_PATH', 'http://angular.contohku.xyz/webservices');
  define('DB_HOST', 'localhost');
  define('DB_NAME', 'contohku_angular');
  define('DB_USERNAME', 'contohku_admin');
  define('DB_PASSWORD', 'Umur25tahun');
  $con = new mysqli(DB_HOST,DB_USERNAME,DB_PASSWORD,DB_NAME);
  if (mysqli_connect_error()) {
    echo('Failed to COnnect' .mysqli_connect_error());
    exit;
  }

?>
